-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2018 at 05:16 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_joinps`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_login`
--

CREATE TABLE `tb_login` (
  `id_petugas` int(3) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` set('admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_login`
--

INSERT INTO `tb_login` (`id_petugas`, `username`, `password`, `status`) VALUES
(4, 'gakim', '1234ps', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_main`
--

CREATE TABLE `tb_main` (
  `id_main` varchar(10) NOT NULL,
  `jenis_ps` enum('ps2','ps3') NOT NULL,
  `waktu_main` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `nama_customer` varchar(100) NOT NULL,
  `id_joiners` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_main`
--

INSERT INTO `tb_main` (`id_main`, `jenis_ps`, `waktu_main`, `total`, `nama_customer`, `id_joiners`) VALUES
('PS001', 'ps3', 3, 15000, 'Euis', 'JN005');

-- --------------------------------------------------------

--
-- Table structure for table `tb_ps`
--

CREATE TABLE `tb_ps` (
  `id_ps` int(3) NOT NULL,
  `jenis_ps` enum('ps2','ps3','','') NOT NULL,
  `biaya_main` int(11) NOT NULL,
  `biaya_rental` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `tb_main`
--
ALTER TABLE `tb_main`
  ADD PRIMARY KEY (`id_main`),
  ADD KEY `id_joiners` (`id_joiners`);

--
-- Indexes for table `tb_ps`
--
ALTER TABLE `tb_ps`
  ADD PRIMARY KEY (`id_ps`),
  ADD KEY `jenis_ps` (`jenis_ps`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_login`
--
ALTER TABLE `tb_login`
  MODIFY `id_petugas` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tb_ps`
--
ALTER TABLE `tb_ps`
  MODIFY `id_ps` int(3) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
