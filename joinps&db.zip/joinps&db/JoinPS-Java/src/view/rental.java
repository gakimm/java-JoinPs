/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.Desktop;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author INIGAKIM
 */
public class rental extends javax.swing.JFrame {

    public Statement st;
    public ResultSet rs;
    public DefaultTableModel tabmodel;
    Connection con = koneksi.koneksi.Conn();
    /**
     * Creates new form rental
     */

    public int harga, lama, total;

    public static void openWebpage(String url) {
        try {
            Desktop.getDesktop().browse(new URL(url).toURI());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public rental() {
        initComponents();
        autorental();
        autotrans();
        tampil();
        judul();
        bayar();
        btn_del.setEnabled(false);
        btn_update.setEnabled(false);
        id();
    }
    
     public void autotrans() {
        try {
            rs = con.createStatement().executeQuery("Select * from tb_trans_rental order by id_trans_rental desc");
            if (rs.next()) {
                String kode = rs.getString("id_trans_rental").substring(3);
                String an = "" + (Integer.parseInt(kode) + 1);
                String nol = "";

                if (an.length() == 1) {
                    nol = "00";
                } else if (an.length() == 2) {
                    nol = "0";
                } else if (an.length() == 3) {
                    nol = "";
                }
                id_trental.setText("TRT" + nol + an);
            } else {
                id_trental.setText("TRT001");
            }
            id_trental.enable(false);
            rs.close();
        } catch (Exception e) {
        }
    }
    
    public void autorental() {
        try {
            rs = con.createStatement().executeQuery("Select * from tb_rental order by id_rental desc");
            if (rs.next()) {
                String kode = rs.getString("id_rental").substring(2);
                String an = "" + (Integer.parseInt(kode) + 1);
                String nol = "";

                if (an.length() == 1) {
                    nol = "00";
                } else if (an.length() == 2) {
                    nol = "0";
                } else if (an.length() == 3) {
                    nol = "";
                }
                id_rental.setText("RT" + nol + an);
            } else {
                id_rental.setText("RT001");
            }
            id_rental.enable(false);
            rs.close();
        } catch (Exception e) {
        }
    }
    
     public void id(){
        try {
            st = con.createStatement();
            rs = st.executeQuery("SELECT * FROM tb_joiners where keterangan='on'");
            while (rs.next()) {
               
                id_joiners.setText(rs.getString("id_joiners"));
                
               
           }
        } catch (Exception e) {
            e.printStackTrace();
            
        }
    }

    public void bayar() {
        if (txt_total2.getText().equals("")) {
            txt_bayar.enable(false);
            txt_kembali.enable(false);
            txt_total2.enable(false);
        } else {
             txt_total2.enable(false);
            txt_bayar.enable(true);
            txt_kembali.enable(true);
            int a = Integer.parseInt(txt_total2.getText());
            int b = Integer.parseInt(txt_bayar.getText());
            int c;

            c = b - a;
            txt_kembali.setText(String.valueOf(c));
        }
    }

    public void reset() {
        nama_customer.setText("");
        txt_permalam.setText("");
        txt_lama.setText("");
        txt_total.setText("");
        txt_jaminan.setText("");
        txt_nomor.setText("");
        txt_keterangan.setText("");
        txt_alamat.setText("");
        buttonGroup1.clearSelection();
    }

    
    public void resetall() {
        id_rental2.setText("");
        nama_customer.setText("");
        txt_permalam.setText("");
        txt_lama.setText("");
        txt_total.setText("");
        txt_jaminan.setText("");
        txt_nomor.setText("");
        txt_keterangan.setText("");
        txt_alamat.setText("");
        txt_total2.setText("");
        buttonGroup1.clearSelection();
        txt_bayar.setText("");
        txt_kembali.setText("");
    }

    public void tampil() {
         try {
            st = con.createStatement();
            tabmodel.getDataVector().removeAllElements();
            tabmodel.fireTableDataChanged();
            rs = st.executeQuery("SELECT * FROM tb_tmp_rental");
            while (rs.next()) {
                Object[] data = {
                    rs.getString("id_rental"),
                    rs.getString("nama_customer"),
                    rs.getString("jenis_ps"),
                    rs.getString("lama_sewa"),
                    rs.getString("total"),
                    rs.getString("jaminan"),
                    rs.getString("no_hp"),
                    rs.getString("keterangan"),
                    rs.getString("alamat"),
                    rs.getString("id_joiners"),
                };
                tabmodel.addRow(data);
            }
        } catch (Exception e) {
        }
    }

    public void judul() {
        Object[] judul = {"ID Rental","Nama Customer","Jenis PS","Lama Sewa","Total","Jaminan","No HP","Keterangan","Alamat","ID Joiners"};
        tabmodel = new DefaultTableModel(null,judul){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tmenu.setModel(tabmodel);
    }

   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        ps2 = new javax.swing.JRadioButton();
        ps3 = new javax.swing.JRadioButton();
        jLabel9 = new javax.swing.JLabel();
        txt_permalam = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nama_customer = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        id_rental = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txt_lama = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        btn_hitung = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txt_total = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        btn_add = new javax.swing.JButton();
        btn_del = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        btn_clear = new javax.swing.JButton();
        txt_jaminan = new javax.swing.JTextField();
        jSeparator11 = new javax.swing.JSeparator();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txt_keterangan = new javax.swing.JTextField();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        jSeparator14 = new javax.swing.JSeparator();
        txt_alamat = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txt_nomor = new javax.swing.JTextField();
        jSeparator15 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        tcari = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tmenu = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        id_joiners = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        txt_kembali = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        txt_bayar = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        id_trental = new javax.swing.JTextField();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel12 = new javax.swing.JLabel();
        id_rental2 = new javax.swing.JTextField();
        jSeparator7 = new javax.swing.JSeparator();
        jLabel13 = new javax.swing.JLabel();
        txt_total2 = new javax.swing.JTextField();
        jSeparator8 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("ID RENTAL");

        ps2.setBackground(new java.awt.Color(0, 153, 153));
        buttonGroup1.add(ps2);
        ps2.setText("Playstation2");
        ps2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ps2ActionPerformed(evt);
            }
        });

        ps3.setBackground(new java.awt.Color(0, 153, 153));
        buttonGroup1.add(ps3);
        ps3.setText("Playstation3");
        ps3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ps3ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Jenis Playstation");

        txt_permalam.setBackground(new java.awt.Color(0, 153, 153));
        txt_permalam.setForeground(new java.awt.Color(255, 255, 255));
        txt_permalam.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_permalam.setBorder(null);
        txt_permalam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_permalamActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Biaya Per Malam");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Nama Pelanggan");

        nama_customer.setBackground(new java.awt.Color(0, 153, 153));
        nama_customer.setForeground(new java.awt.Color(255, 255, 255));
        nama_customer.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nama_customer.setBorder(null);

        id_rental.setBackground(new java.awt.Color(0, 153, 153));
        id_rental.setForeground(new java.awt.Color(255, 255, 255));
        id_rental.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        id_rental.setBorder(null);
        id_rental.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_rentalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator1)
                            .addComponent(jSeparator4)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(nama_customer))
                            .addComponent(jSeparator5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txt_permalam))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                        .addComponent(ps2)
                        .addGap(65, 65, 65)
                        .addComponent(ps3)
                        .addGap(86, 86, 86))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(id_rental)
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(148, 148, 148))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(147, 147, 147))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(168, 168, 168))))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(148, 148, 148))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(id_rental, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(2, 2, 2)
                .addComponent(nama_customer, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel9)
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ps3)
                    .addComponent(ps2))
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_permalam, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jPanel8.setBackground(new java.awt.Color(0, 75, 36));

        jLabel21.setFont(new java.awt.Font("Harlow Solid Italic", 0, 36)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Join Ps - Station");

        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel21)
                .addGap(289, 289, 289)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(0, 153, 153));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Lama Sewa");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Malam");

        txt_lama.setBackground(new java.awt.Color(0, 153, 153));
        txt_lama.setForeground(new java.awt.Color(255, 255, 255));
        txt_lama.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_lama.setBorder(null);
        txt_lama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_lamaActionPerformed(evt);
            }
        });

        btn_hitung.setText("Hitung");
        btn_hitung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hitungActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Total");

        txt_total.setBackground(new java.awt.Color(0, 153, 153));
        txt_total.setForeground(new java.awt.Color(255, 255, 255));
        txt_total.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_total.setBorder(null);
        txt_total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalActionPerformed(evt);
            }
        });
        txt_total.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_totalKeyTyped(evt);
            }
        });

        btn_add.setFont(new java.awt.Font("Raleway", 1, 12)); // NOI18N
        btn_add.setText("SIMPAN");
        btn_add.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        btn_add.setContentAreaFilled(false);
        btn_add.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_add.setIconTextGap(2);
        btn_add.setOpaque(true);
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });

        btn_del.setBackground(new java.awt.Color(217, 30, 24));
        btn_del.setFont(new java.awt.Font("Raleway", 1, 12)); // NOI18N
        btn_del.setForeground(new java.awt.Color(255, 255, 255));
        btn_del.setText("DELETE");
        btn_del.setBorder(null);
        btn_del.setContentAreaFilled(false);
        btn_del.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_del.setIconTextGap(2);
        btn_del.setOpaque(true);
        btn_del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_delActionPerformed(evt);
            }
        });

        btn_update.setBackground(new java.awt.Color(204, 204, 0));
        btn_update.setFont(new java.awt.Font("Raleway", 1, 12)); // NOI18N
        btn_update.setForeground(new java.awt.Color(255, 255, 255));
        btn_update.setText("UPDATE");
        btn_update.setBorder(null);
        btn_update.setBorderPainted(false);
        btn_update.setContentAreaFilled(false);
        btn_update.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_update.setIconTextGap(2);
        btn_update.setOpaque(true);
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        btn_clear.setBackground(new java.awt.Color(23, 32, 41));
        btn_clear.setFont(new java.awt.Font("Raleway", 1, 12)); // NOI18N
        btn_clear.setForeground(new java.awt.Color(204, 204, 204));
        btn_clear.setText("Reset");
        btn_clear.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        btn_clear.setContentAreaFilled(false);
        btn_clear.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_clear.setIconTextGap(2);
        btn_clear.setOpaque(true);
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        txt_jaminan.setBackground(new java.awt.Color(0, 153, 153));
        txt_jaminan.setForeground(new java.awt.Color(255, 255, 255));
        txt_jaminan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_jaminan.setBorder(null);
        txt_jaminan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_jaminanActionPerformed(evt);
            }
        });
        txt_jaminan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_jaminanKeyTyped(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("Jaminan");

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Keterangan");

        txt_keterangan.setBackground(new java.awt.Color(0, 153, 153));
        txt_keterangan.setForeground(new java.awt.Color(255, 255, 255));
        txt_keterangan.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_keterangan.setBorder(null);
        txt_keterangan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_keteranganActionPerformed(evt);
            }
        });
        txt_keterangan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_keteranganKeyTyped(evt);
            }
        });

        txt_alamat.setBackground(new java.awt.Color(0, 153, 153));
        txt_alamat.setForeground(new java.awt.Color(255, 255, 255));
        txt_alamat.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_alamat.setBorder(null);
        txt_alamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_alamatActionPerformed(evt);
            }
        });
        txt_alamat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_alamatKeyTyped(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("Alamat");

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel20.setText("No HP");

        txt_nomor.setBackground(new java.awt.Color(0, 153, 153));
        txt_nomor.setForeground(new java.awt.Color(255, 255, 255));
        txt_nomor.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_nomor.setBorder(null);
        txt_nomor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomorActionPerformed(evt);
            }
        });
        txt_nomor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nomorKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txt_total)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(56, 56, 56))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(txt_lama, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(29, 29, 29)
                        .addComponent(btn_hitung, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_jaminan)
                    .addComponent(jSeparator11)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(jLabel5))
                    .addComponent(jSeparator13)
                    .addComponent(txt_nomor)
                    .addComponent(jSeparator15))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(127, 127, 127)
                                        .addComponent(jLabel17))
                                    .addComponent(txt_keterangan, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btn_del, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btn_clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jSeparator14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_alamat, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel19)
                        .addGap(152, 152, 152))))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(jLabel16)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(6, 6, 6)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_lama, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)
                            .addComponent(btn_hitung, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_keterangan, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator12)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_total, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jSeparator13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_alamat, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSeparator14)))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_jaminan, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_nomor, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator15, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_del, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(0, 75, 36));

        tcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tcariActionPerformed(evt);
            }
        });
        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcariKeyReleased(evt);
            }
        });

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/searching-magnifying-glass (1).png"))); // NOI18N

        tmenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tmenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tmenuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tmenu);

        jLabel7.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 204, 0));
        jLabel7.setText("ID Joiners :");

        id_joiners.setFont(new java.awt.Font("Prestige Elite Std", 0, 18)); // NOI18N
        id_joiners.setForeground(new java.awt.Color(255, 255, 255));
        id_joiners.setBorder(javax.swing.BorderFactory.createCompoundBorder());

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(id_joiners, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tcari)
                .addContainerGap())
            .addComponent(jScrollPane1)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel7)
                        .addComponent(id_joiners, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tcari, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(7, 7, 7)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(0, 75, 36));

        jButton2.setFont(new java.awt.Font("Tekton Pro Ext", 1, 11)); // NOI18N
        jButton2.setText("CETAK STRUK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        txt_kembali.setBackground(new java.awt.Color(0, 75, 36));
        txt_kembali.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txt_kembali.setForeground(new java.awt.Color(255, 255, 255));
        txt_kembali.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_kembali.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_kembali.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_kembaliKeyReleased(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("KEMBALI");

        txt_bayar.setBackground(new java.awt.Color(0, 75, 36));
        txt_bayar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txt_bayar.setForeground(new java.awt.Color(255, 255, 255));
        txt_bayar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_bayar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_bayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_bayarKeyReleased(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("BAYAR");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ID TRANSAKSI RENTAL");

        id_trental.setBackground(new java.awt.Color(0, 75, 36));
        id_trental.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        id_trental.setForeground(new java.awt.Color(255, 255, 255));
        id_trental.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        id_trental.setBorder(null);
        id_trental.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_trentalActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("ID RENTAL");

        id_rental2.setEditable(false);
        id_rental2.setBackground(new java.awt.Color(0, 75, 36));
        id_rental2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        id_rental2.setForeground(new java.awt.Color(255, 255, 255));
        id_rental2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        id_rental2.setBorder(null);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("TOTAL");

        txt_total2.setBackground(new java.awt.Color(0, 75, 36));
        txt_total2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_total2.setForeground(new java.awt.Color(255, 255, 255));
        txt_total2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_total2.setBorder(null);
        txt_total2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_total2ActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Eras Demi ITC", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 204, 0));
        jLabel18.setText("FORM PEMBAYARAN");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jSeparator6)
                                    .addComponent(id_trental, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel1))
                            .addGap(46, 46, 46)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel14)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jSeparator10)
                                            .addComponent(txt_kembali, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jLabel15))
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jSeparator9)
                                        .addComponent(txt_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel12)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jSeparator7)
                                    .addComponent(id_rental2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel6Layout.createSequentialGroup()
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel13)
                                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jSeparator8)
                                            .addComponent(txt_total2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(45, 45, 45)
                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addGap(41, 41, 41)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(4, 4, 4)
                                .addComponent(id_trental, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(4, 4, 4)
                                .addComponent(txt_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(id_rental2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(4, 4, 4)
                        .addComponent(txt_kembali, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_total2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ps2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ps2ActionPerformed
        // TODO add your handling code here:
        txt_permalam.setText("25000");
    }//GEN-LAST:event_ps2ActionPerformed

    private void ps3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ps3ActionPerformed
        // TODO add your handling code here:
        txt_permalam.setText("50000");
    }//GEN-LAST:event_ps3ActionPerformed

    private void txt_permalamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_permalamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_permalamActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

        home vl = new home();
        vl.show();
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txt_lamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_lamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_lamaActionPerformed

    private void btn_hitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hitungActionPerformed
        // TODO add your handling code here:

        if (id_rental.getText().equals("") || txt_lama.getText().equals("") || txt_permalam.getText().equals("")) {
            JOptionPane.showMessageDialog(null, " Lengkapi Data Terlebih Dahulu ! !");
        } else {
            lama = Integer.parseInt(txt_lama.getText());
            harga = Integer.parseInt(txt_permalam.getText());
            total = lama * harga;

            txt_total.setText(total + "");
        }
    }//GEN-LAST:event_btn_hitungActionPerformed

    private void txt_totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalActionPerformed

    private void txt_totalKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_totalKeyTyped
        // TODO add your handling code here:
        char karakter = evt.getKeyChar();
        if (!(((karakter >= '0') && (karakter <= '9') || (karakter == KeyEvent.VK_BACK_SPACE) || (karakter == KeyEvent.VK_DELETE)))) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txt_totalKeyTyped

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        if (nama_customer.getText().equals("") || txt_lama.getText().equals("") || txt_total.getText().equals("") || txt_jaminan.getText().equals("") || txt_nomor.getText().equals("") || txt_keterangan.getText().equals("") || txt_alamat.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Harap Lengkapi Data");
        }else{
            try {
                String hasil;
                if (ps2.isSelected()) {
                    hasil = "ps2";
                } else {
                    hasil = "ps3";
                }
                st = con.createStatement();
                st.executeUpdate("INSERT INTO tb_rental SET " + " id_rental='" + id_rental.getText() + "', nama_customer = '" + nama_customer.getText() + "',jenis_ps = '" + hasil + "',lama_sewa = '" + txt_lama.getText() + "', total = '" + txt_total.getText() + "',jaminan = '" + txt_jaminan.getText() + "',no_hp = '" + txt_nomor.getText() + "', keterangan ='" + txt_keterangan.getText() + "',alamat = '" + txt_alamat.getText() + "', id_joiners = '" + id_joiners.getText() + "'");
                st.executeUpdate("INSERT INTO tb_tmp_rental SET " + " id_rental='" + id_rental.getText() + "', nama_customer = '" + nama_customer.getText() + "',jenis_ps = '" + hasil + "',lama_sewa = '" + txt_lama.getText() + "', total = '" + txt_total.getText() + "',jaminan = '" + txt_jaminan.getText() + "',no_hp = '" + txt_nomor.getText() + "', keterangan ='" + txt_keterangan.getText() + "',alamat = '" + txt_alamat.getText() + "', id_joiners = '" + id_joiners.getText() + "'");
                judul();
                tampil();
                JOptionPane.showMessageDialog(null, "DATA BERHASIL DI INPUT");
                autorental();
                buttonGroup1.clearSelection();
                reset();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_btn_addActionPerformed

    private void btn_delActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_delActionPerformed
        // TODO add your handling code here:
        try {
            st = con.createStatement();
            st.executeUpdate("DELETE FROM tb_tmp_rental WHERE " + " id_rental='" + tabmodel.getValueAt(tmenu.getSelectedRow(), 0) + "'");
             st.executeUpdate("DELETE FROM tb_rental WHERE " + " id_rental='" + tabmodel.getValueAt(tmenu.getSelectedRow(), 0) + "'");
            int a = JOptionPane.showConfirmDialog(null, "Yakin ingin Menghapus ??", "Informasi", JOptionPane.YES_NO_OPTION);
            if (a == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus !");
                tampil();
                reset();
                autorental();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_btn_delActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        // TODO add your handling code here:
        try {

            String hasil;

            if (ps2.isSelected()) {
                hasil = "ps2";
            } else {
                hasil = "ps3";
            }

            st = con.createStatement();
            st.executeUpdate("UPDATE tb_rental SET " + " id_rental='" + id_rental.getText() + "', nama_customer = '" + nama_customer.getText() + "',jenis_ps = '" + hasil + "',lama_sewa = '" + txt_lama.getText() + "', total = '" + txt_total.getText() + "',jaminan = '" + txt_jaminan.getText() + "',no_hp = '" + txt_nomor.getText() + "', keterangan ='" + txt_keterangan.getText() + "',alamat = '" + txt_alamat.getText() + "', id_joiners = '" + id_joiners.getText() + "', where id_rental='" + id_rental.getText() + "'");
            st.executeUpdate("UPDATE tb_tmp_rental SET " + " id_rental='" + id_rental.getText() + "', nama_customer = '" + nama_customer.getText() + "',jenis_ps = '" + hasil + "',lama_sewa = '" + txt_lama.getText() + "', total = '" + txt_total.getText() + "',jaminan = '" + txt_jaminan.getText() + "',no_hp = '" + txt_nomor.getText() + "', keterangan ='" + txt_keterangan.getText() + "',alamat = '" + txt_alamat.getText() + "', id_joiners = '" + id_joiners.getText() + "', where id_rental='" + id_rental.getText() + "'");

            JOptionPane.showMessageDialog(null, "Data Berhasil Di Update");
            tampil();
            reset();
            autorental();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        if (nama_customer.getText().equals("")||txt_lama.getText().equals("")||txt_permalam.getText().equals("")||txt_total.getText().equals("")||txt_jaminan.getText().equals("")||txt_nomor.getText().equals("")||txt_keterangan.getText().equals("")||txt_alamat.getText().equals("")) {
             JOptionPane.showMessageDialog(null, " Tidak ada data untuk direset !");
        }else{
            reset();
            autorental();
            btn_add.setEnabled(true);
        }
    }//GEN-LAST:event_btn_clearActionPerformed

    private void txt_jaminanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_jaminanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jaminanActionPerformed

    private void txt_jaminanKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_jaminanKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jaminanKeyTyped

    private void txt_keteranganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_keteranganActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_keteranganActionPerformed

    private void txt_keteranganKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_keteranganKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_keteranganKeyTyped

    private void txt_alamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_alamatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_alamatActionPerformed

    private void txt_alamatKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_alamatKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_alamatKeyTyped

    private void txt_nomorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomorActionPerformed

    private void txt_nomorKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nomorKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomorKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (id_rental2.getText().equals("") || txt_bayar.getText().equals("") || txt_total2.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Data Kosong !");
        } else {
            try {
                int b = Integer.valueOf(txt_bayar.getText());
                int a = Integer.valueOf(txt_total2.getText());
                if (a > b) {
                    JOptionPane.showMessageDialog(null, " Uang Kurang !!", "Informasi", JOptionPane.ERROR_MESSAGE);
                } else if (txt_bayar.getText().equals("") || txt_total2.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Uangnya Masukin Dulu !", "Informasi", JOptionPane.ERROR_MESSAGE);
                } else if (txt_total2.getText().equals("") || id_rental2.getText().equals(" ")) {
                    JOptionPane.showMessageDialog(null, "Tidak Ada Data Untuk Di Kelola ", "Informasi", JOptionPane.ERROR_MESSAGE);
                } else {
                    st = con.createStatement();
                    st.executeUpdate("INSERT INTO tb_trans_rental SET " + "id_trans_rental='" + id_trental.getText() + "',id_rental ='" + id_rental2.getText() + "', total='" + txt_total2.getText() + "', bayar='" + txt_bayar.getText() + "', kembali='" + txt_kembali.getText() + "', id_joiners ='" + id_joiners.getText() + "'");
                    st.executeUpdate("DELETE FROM tb_tmp_rental WHERE " + " id_rental='" + tabmodel.getValueAt(tmenu.getSelectedRow(), 0) + "'");
                    JOptionPane.showMessageDialog(null, "Pembelian Berhasil !", "Informasi", JOptionPane.INFORMATION_MESSAGE);

                    openWebpage("http://localhost:81/joinps_java/report_rental.php?id=" + id_trental.getText());
                    //Desktop.getDesktop().browse(new URL().toURI());

                    autorental();
                    resetall();

                }

            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txt_kembaliKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_kembaliKeyReleased
        // TODO add your handling code here:
        bayar();
    }//GEN-LAST:event_txt_kembaliKeyReleased

    private void txt_bayarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_bayarKeyReleased
        // TODO add your handling code here:
        bayar();
    }//GEN-LAST:event_txt_bayarKeyReleased

    private void id_trentalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_trentalActionPerformed

    }//GEN-LAST:event_id_trentalActionPerformed

    private void tmenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tmenuMouseClicked
        id_rental.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 0) + "");
        id_rental2.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 0) + "");
        nama_customer.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 1) + "");
        switch (tabmodel.getValueAt(tmenu.getSelectedRow(), 2).toString()) {
            case "ps2":
                ps2.setSelected(true);
                txt_permalam.setText("25000");
                break;
            case "ps3":
                ps3.setSelected(true);
                txt_permalam.setText("50000");
                break;
        }
        txt_lama.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 3) + "");
        txt_total.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 4) + "");
        txt_total2.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 4) + "");
        txt_jaminan.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 5) + "");
        txt_nomor.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 6) + "");
        txt_keterangan.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 7) + "");
        txt_alamat.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 8) + "");

        id_joiners.setText(tabmodel.getValueAt(tmenu.getSelectedRow(), 9) + "");
        btn_add.setEnabled(false);
        btn_del.setEnabled(true);
        btn_update.setEnabled(true);
        txt_bayar.enable(true);
        
    }//GEN-LAST:event_tmenuMouseClicked

    private void tcariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyReleased
        // TODO add your handling code here:
        try {
            st = con.createStatement();
            tabmodel.getDataVector().removeAllElements();
            tabmodel.fireTableDataChanged();
            rs = st.executeQuery("SELECT * FROM tb_tmp_rental WHERE id_rental like '%" + tcari.getText() + "%' or nama_customer like '%" + tcari.getText() + "%' or jenis_ps like '%" + tcari.getText() + "%' or lama_sewa like '%" + tcari.getText() + "%' or  total like '%" + tcari.getText() + "%' or jaminan like '%" + tcari.getText() + "%'" + "%' or keterangan like '%" + tcari.getText() + "%'" + "%' or alamat like '%" + tcari.getText() + "%'");
            while (rs.next()) {
                Object[] data = {
                    rs.getString("id_rental"),
                    rs.getString("nama_customer"),
                    rs.getString("jenis_ps"),
                    rs.getString("lama_sewa"),
                    rs.getString("total"),
                    rs.getString("jaminan"),
                    rs.getString("no_hp"),
                    rs.getString("keterangan"),
                    rs.getString("alamat"),
                    rs.getString("id_joiners"),};
                tabmodel.addRow(data);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_tcariKeyReleased

    private void tcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tcariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tcariActionPerformed

    private void txt_total2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_total2ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txt_total2ActionPerformed

    private void id_rentalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_rentalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_id_rentalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(rental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(rental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(rental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(rental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new rental().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_del;
    private javax.swing.JButton btn_hitung;
    private javax.swing.JButton btn_update;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel id_joiners;
    private javax.swing.JTextField id_rental;
    private javax.swing.JTextField id_rental2;
    private javax.swing.JTextField id_trental;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextField nama_customer;
    private javax.swing.JRadioButton ps2;
    private javax.swing.JRadioButton ps3;
    private javax.swing.JTextField tcari;
    private javax.swing.JTable tmenu;
    private javax.swing.JTextField txt_alamat;
    private javax.swing.JTextField txt_bayar;
    private javax.swing.JTextField txt_jaminan;
    private javax.swing.JTextField txt_kembali;
    private javax.swing.JTextField txt_keterangan;
    private javax.swing.JTextField txt_lama;
    private javax.swing.JTextField txt_nomor;
    private javax.swing.JTextField txt_permalam;
    private javax.swing.JTextField txt_total;
    private javax.swing.JTextField txt_total2;
    // End of variables declaration//GEN-END:variables

}
